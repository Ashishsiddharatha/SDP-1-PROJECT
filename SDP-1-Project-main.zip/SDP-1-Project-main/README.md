# DOCUMENTATION
Linked In Article Link: https://www.linkedin.com/pulse/service-management-system-prasanth-gunnam/ <br>
## USE CASE Diagram:<br>
![image](https://user-images.githubusercontent.com/91374818/138872079-e65fe585-659c-47cd-9b68-1770aedf3e6a.png)<br>
## SEQUENCE Diagram:<br>
![image](https://user-images.githubusercontent.com/91374818/138872250-464f2721-1614-4037-8c86-d90b43e3f9a2.png)<br>
## ACTIVITY Diagram:<br>
![image](https://user-images.githubusercontent.com/91374818/138872307-e6e2e9b7-a519-4cde-802d-2333f71b7a2b.png)<br>
## Front End User Page:<br>
https://klez-sap.netlify.app/

User Stories:
As a User I want to access the service management system so that I can book services online.
As a User I want to access the service management system so that I can check my profile.

As a ServiceMan I want to access the service management system so that I can accept services online.
As a ServiceMan i want to access the service management system so that I can check collect my Paywork.
